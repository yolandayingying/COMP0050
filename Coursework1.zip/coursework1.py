#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# recall = TP/(TP+FN) # make negative out   (sensitivity)
# precision = TP/(TP+FP) # waste testing ()

import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report
import matplotlib.pyplot as plt
from sklearn.preprocessing import PolynomialFeatures
from sklearn import metrics
from sklearn.metrics import confusion_matrix

column_names = ['loan_amnt','term','installment','emp_length','home_ownership','verification_status','dti','earliest_cr_line','open_acc','pub_rec','revol_util','total_acc','application_type','mort_acc','pub_rec_bankruptcies','log_annual_inc','fico_score','log_revol_bal','charged_off']
data = pd.read_csv('dataCOMP0050Coursework1.csv')
data = data.replace(to_replace=' ', value=np.nan)
data = data.dropna()



selected_column_names = column_names[0:18]
x_train, x_test, y_train, y_test = train_test_split(data[selected_column_names], data[column_names[18]], test_size=0.3)
std = StandardScaler()
x_train = std.fit_transform(x_train)
x_test = std.transform(x_test)
poly = PolynomialFeatures(1)
x_train_poly = poly.fit_transform(x_train)

for c in range(1,2):
    # Logistic Regression
    lr = LogisticRegression(C=0.1*c, max_iter=1500, random_state=0, class_weight={0:0.6,1:3})
    lr.fit(x_train_poly,y_train)
    x_test_poly = poly.fit_transform(x_test)
    y_pred = lr.predict(x_test_poly)
    print("Logistic Regression")
    y_prob = lr.predict_proba(x_test_poly)[:,1]
    fpr_lr,tpr_lr,thre_lr = metrics.roc_curve(y_test,y_prob)
    auc_lr = metrics.auc(fpr_lr,tpr_lr) 
    y_train_pred = lr.predict(x_train_poly)
    print("train_Accuracy：", metrics.accuracy_score(y_train,y_train_pred))
    print("Accuracy：", metrics.accuracy_score(y_test,y_pred))
    print("Pecision: ", metrics.precision_score(y_test,y_pred))
    print("Recall: ", metrics.recall_score(y_test,y_pred))
    print("auc_score: ",auc_lr)
    print("--------------------")
    C = confusion_matrix(y_test,y_pred)
#print(C)

# Random Forest Classifier
from sklearn.ensemble import RandomForestClassifier


rfc = RandomForestClassifier(class_weight={0:0.6,1:3})
rfc.fit(x_train_poly,y_train)
y_pred = rfc.predict(x_test_poly)
print("Random Forest Classifier")
y_prob = rfc.predict_proba(x_test_poly)[:,1]
fpr_rfc,tpr_rfc,thre_rfc = metrics.roc_curve(y_test,y_prob)
auc_rfc = metrics.auc(fpr_rfc,tpr_rfc) 
print("Accuracy：", metrics.accuracy_score(y_test,y_pred))
print("Pecision: ", metrics.precision_score(y_test,y_pred))
print("Recall: ", metrics.recall_score(y_test,y_pred))
print("auc_score: ",auc_rfc)
print("--------------------")


# Decision tree
from sklearn import tree

dtc = tree.DecisionTreeClassifier(class_weight={0:0.6,1:3})                             
dtc.fit(x_train_poly,y_train)                                         
y_pred = dtc.predict(x_test_poly)  
print("Decision tree")
y_prob = dtc.predict_proba(x_test_poly)[:,1]                                   
fpr_dtc,tpr_dtc,thre_dtc= metrics.roc_curve(y_test,y_prob) 
auc_dtc = metrics.auc(fpr_dtc,tpr_dtc)
print("Accuracy：", metrics.accuracy_score(y_test,y_pred))
print("Pecision: ", metrics.precision_score(y_test,y_pred))
print("Recall: ", metrics.recall_score(y_test,y_pred))
print("auc_score: ",auc_dtc)
print("--------------------")
# ROC curve
plt.style.use('bmh')
plt.figure(figsize=(12,10))
plt.plot(fpr_lr,tpr_lr,label='Logistic Regression')                            
plt.plot(fpr_dtc,tpr_dtc,label='Decision tree Classifier')                       
plt.plot(fpr_rfc,tpr_rfc,label='Random Forest Classifier')                     
plt.legend(loc='lower right',prop={'size':25})
plt.xlabel('Fake_Positive')
plt.ylabel('True_Positive')
plt.title('ROC Curve')
plt.show()